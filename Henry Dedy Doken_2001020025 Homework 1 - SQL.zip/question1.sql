-- Q1
-- :List all Category Names ordered alphabetically.

SELECT CategoryName FROM Category ORDER BY CategoryName ASC;

-- Output:
-- Beverages
-- Condiments
-- Confections
-- Dairy Products
-- Grains/Cereals
-- Meat/Poultry
-- Produce
-- Seafood