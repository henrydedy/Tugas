-- Q2
-- : Get all unique ShipNames from the Order table that contain a hyphen '-' .
--  In addition, get all the characters preceding the (first) hyphen. 
--  Return ship names alphabetically. Your first row

-- Notes:
-- SUBSTR(string, start, length) or SUBSTR(string FROM start FOR length)
-- INSTR( The string that will be searched, The string to search for in string1. If string2 is not found, this function returns 0)

SELECT DISTINCT ShipName, substr(ShipName, 0, instr(ShipName, '-')) as PreHyphen
FROM 'Order'
WHERE ShipName LIKE '%-%'
ORDER BY ShipName ASC;

-- OUTPUT:
-- Bottom-Dollar Markets|Bottom
-- Chip-Delicateses|Chip
-- Donuts-Stop|Donuts
-- House-a-lot Markets|House
-- LIPS-suey Chinese|LIPS
-- Maccarony-Restaurante|Maccarony
-- Omicron-Abastos|Omicron
-- The Beast All-Night Grocers|The Beast All
-- ZebraCrozz-Supermercado|ZebraCrozz

